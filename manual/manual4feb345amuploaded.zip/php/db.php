<?php

	$conn = mysqli_connect("localhost","admin","root","manualaadhrita");
?>