<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
	<meta name="author" content="SAIKIRAN SEEPANA" >
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.min.css">
</head>
<body>
	<div class="container" style="padding-top: 100px;">
		<div class="jumbotron" >
			<h2 style="color: red;" >ERROR</h2>
			<h3>Credentials you entered are Wrong</h3>
			<h3>Try logging with valid credentials</h3>
			<h3>or</h3>
			<h3>You didn't loggedin</h3>
			<h3> Try to access this page after logging in </h3>
		</div>
	</div>
</body>
</html>