<?php

	$conn = mysqli_connect("localhost","aadhrita","After8years","manualaadhrita");
?>